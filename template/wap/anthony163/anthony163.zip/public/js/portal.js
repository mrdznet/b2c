//tab切换
$(document).ready(function() {
     $("#tab li").click(function() {
         $("#tab li").eq($(this).index()).addClass("avtive").siblings().removeClass('avtive');
         $(".portal_list").hide().eq($(this).index()).show();
     });
});
